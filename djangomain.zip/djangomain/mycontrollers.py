from django import http
import pymysql
from django.shortcuts import *
def sample(request):
    return render(request,"one.html")
def process(request):
    s=request.GET["tb1"]
    s=str(s).upper()
    return HttpResponse(s)
def dict(request):
    s=""
    p=[{"rollno.":1,"name":"DIVYANSHU","course":"Btech"},
       {"rollno.":2, "name": "Gaganjot", "course": "Btech"},
       {"rollno.":3, "name": "Sukhman", "course": "Btech"},
       {"rollno.":4, "name": "Bharat", "course": "Btech"},
       {"rollno.":5, "name": "Danish", "course": "Btech"},]
    a=int(request.GET["tb1"])
    for x in p:
        if x["rollno."]== a:
            s=s+str(x["rollno."])+" "+x["name"]+" "+x["course"]
    return HttpResponse(s)

def dict1(request):
    s=""
    p=[{"rollno.":1,"name":"Divyanshu","course":"Btech"},
       {"rollno.":2, "name": "Gaganjot", "course": "Btech"},
       {"rollno.":3, "name": "Sukhman", "course": "Btech"},
       {"rollno.":4, "name": "Bharat", "course": "Btech"},
       {"rollno.":5, "name": "Danish", "course": "Btech"},]
    a=int(request.GET["tb1"])
    s=s+"<table>"
    for x in p:
        s=s+"<tr>"
        s=s+"<td>"+str(x["rollno."])+"</td>"
        s=s+"<td>"+str(x["name"])+"</td>"
        s=s+"<td>"+str(x["course"])+"</td>"
        s=s+"</tr>"
    s=s+"</table>"
    return HttpResponse(s)

#loginpage-----------------------------------------

def login(request):
    return render(request,"login.html")
def loginpage(request):
    return render(request,"loggedpage.html")
def checkpass(request):
    data = [{"name":"deepu", "pass":"12345"}, {"name":"gaggi", "pass":"hello"}]
    flag=False
    a=request.POST["tb1"]
    b=request.POST["tb2"]
    for x in data:
        if x["name"]==a and x["pass"]==b:

            flag=True
    if flag==True:
        return HttpResponseRedirect("loggedpage")
    else:
        return HttpResponseRedirect("login")
#database------------------------------------------
def showdpage(request):
    return render(request,"databasehtml.html")
def addcourse(request):
    coursename=request.GET["tb1"]
    hod = request.GET["tb2"]
    floor1 = request.GET["tb3"]
    conn=pymysql.connect("127.0.0.1","root",'',"demo")
    query="insert into course values ('"+coursename+"','"+hod+"','"+floor1+"')";
    cr=conn.cursor()
    cr.execute(query)
    conn.commit()
    conn.close()
    return HttpResponse("<h1>course added successfull</h1>")
def viewmembers(request):
    conn=pymysql.connect("127.0.0.1","root",'',"demo")
    query="select * from course"
    cr=conn.cursor()
    cr.execute(query)
    result=cr.fetchall()
    s="<table>"
    for p in result:
        s=s+"<tr>"
        s=s+"<td>"+p[0]+"</td>"
        s=s+"<td>"+p[1]+"</td>"
        s=s+"<td>"+p[2]+"</td>"
        s=s+"</tr>"
    s=s+"</table>"
    return HttpResponse(s)
#---------------------------------------------
def courserender(request):
    return render(request,"addcourse.html")
#ADD COURSE
def add_course(request):
    import pymysql
    coursename = request.GET["tb1"]
    hod = request.GET["tb2"]
    floor1 = request.GET["tb3"]
    conn = pymysql.connect("127.0.0.1", "root", '', "demo")
    query1="select * from course"
    query2 = "insert into course values ('" + coursename + "','" + hod + "','" + floor1 + "')";
    cr = conn.cursor()
    cr.execute(query1)
    result=cr.fetchall()
    flag=False
    for p in result:
        if p[0]==coursename:
            flag=True
            break
    d={}
    if flag==True:
        d["message"]="Duplicate Course"
    else:
        cr.execute(query2)
        conn.commit()
        conn.close()
        d["message"]="course added successfully"
    return  render(request,"confirmcourse.html",d)




def view_course(request):
    import pymysql
    conn = pymysql.connect("127.0.0.1", "root", '', "demo")
    query = "select * from course"
    cr = conn.cursor()
    cr.execute(query)
    result = cr.fetchall()
    x=[]
    for p in result:
        d={}
        d["coursename"]=p[0]
        d["hod"] = p[1]
        d["floor"] = p[2]
        s=str(p[0]).replace(" ","%20")
        d["removeurl"]="removedata?q="+s
        d["updateurl"] = "updatedata?q=" + s
        x.append(d)
    return render(request,"view course.html",{"mydata":x})
def removedata(request):
    conn=pymysql.connect("127.0.0.1","root",'',"demo")
    s2="select * from student"
    cr=conn.cursor()
    cr.execute(s2)
    result=cr.fetchall()
    flag=False
    for p in result:
        if p[3]== request.GET["q"]:
            flag=True
            break
    d={}
    if flag==True:
        d["message"]="STUDENT ALREADY ENROLLED CANT DELETE"
        return render(request,"delmessage.html",d)
    else:
        s = "delete from course where course='" + request.GET["q"] + "'"
        cr = conn.cursor()
        cr.execute(s)
        conn.commit()
        return HttpResponseRedirect("view_course")



def updatedata(request):

    conn = pymysql.connect("127.0.0.1", "root", '', "demo")
    s="select * from course where course='"+request.GET["q"]+"'"
    cr=conn.cursor()
    cr.execute(s)
    result=cr.fetchone()
    d={}
    d["coursename"]=result[0]
    d["hod"] = result[1]
    d["floor"] = result[2]
    return render(request,"editcourse.html",d)
def save(request):
    conn = pymysql.connect("127.0.0.1", "root", '', "demo")
    s="update course set hod='"+request.GET["tb2"]+"',location='"+request.GET["tb3"]+"'where course='"+request.GET["tb1"]+"'"
    cr=conn.cursor()
    cr.execute(s)
    conn.commit()
    return HttpResponseRedirect("view_course")




#---------------------------------
def studentrender(request):
    import pymysql
    conn = pymysql.connect("127.0.0.1", "root", '', "demo")
    s="select course from course"
    cr=conn.cursor()
    cr.execute(s)
    result=cr.fetchall()
    x=[]
    for p in result:
        d={}
        d["coursename"]=p[0]
        x.append(d)
    return render(request,"add student.html",{"ar":x})
def add_student(request):
    import pymysql
    rollno = request.GET["tb1"]
    name = request.GET["tb2"]
    age = request.GET["tb3"]
    course=request.GET["tb4"]
    conn = pymysql.connect("127.0.0.1", "root", '', "demo")
    query1="select * from student"
    query2 = "insert into student values (" + rollno + ",'" + name + "'," + age + ",'"+course+"')";

    cr=conn.cursor()
    cr.execute(query1)
    result=cr.fetchall()
    flag=False
    for p in result:
        if p[0]== int(rollno)  :

            flag=True
            break
    d={}
    if flag==True:
        d["message1"]="DUPLICATE ROLL NUMBER"
    else:
        cr.execute(query2)
        conn.commit()
        conn.close()
        d["message1"]="Student added successfully"
    return  render(request,"confirmroll.html",d)




def view_student(request):
    import pymysql
    conn = pymysql.connect("127.0.0.1", "root", '', "demo")
    query = "select * from student"
    cr = conn.cursor()
    cr.execute(query)
    result = cr.fetchall()
    x = []
    for p in result:
        d = {}
        d["rollno"] = str(p[0])
        d["name"] = p[1]
        d["age"] = str(p[2])
        d["course"]=p[3]
        s = str(p[0]).replace(" ", "%20")
        d["removeurl1"] = "removedata1?q=" + s
        d["updateurl1"] = "updatedata1?q=" + s

        x.append(d)
    return render(request, "view_student.html", {"mydata": x})
def removedata1(request):
    conn=pymysql.connect("127.0.0.1","root",'',"demo")
    s="delete from student where rollno='"+request.GET["q"]+"'"
    cr=conn.cursor()
    cr.execute(s)
    conn.commit()
    return HttpResponseRedirect("view_student")
def updatedata1(request):
    conn = pymysql.connect("127.0.0.1", "root", '', "demo")
    s="select * from student where rollno='"+request.GET["q"]+"'"
    cr=conn.cursor()
    cr.execute(s)
    result=cr.fetchone()
    d={}
    d["roll"]=result[0]
    d["name"] = result[1]
    d["age"] = result[2]
    d["course"]=result[3]

    return render(request,"editstudent.html",d)
def save1(request):
    conn = pymysql.connect("127.0.0.1", "root", '', "demo")
    s="update student set name='"+request.GET["tb2"]+"'age='"+request.GET["tb3"]+"'where rollno='"+request.GET["tb1"]+"'"
    cr=conn.cursor()
    cr.execute(s)
    conn.commit()
    return HttpResponseRedirect("view_student")













