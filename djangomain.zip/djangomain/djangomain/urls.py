"""djangomain URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from mycontrollers import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('input/',sample,name="one"),
    path('dict1/',dict1),
    path('login/',login,name="login"),
    path('loggedpage/',loginpage,name="loggedpage"),
    path('checkpass',checkpass),
    path('databasepage/',showdpage,name="databasehtml"),
    path('addcourse',addcourse),

    path('viewcourse/',viewmembers),
    path('courseadd',courserender),
    path('add_course',add_course),
    path('view_course',view_course),
    path('removedata',removedata),
    path('updatedata',updatedata),
    path('save',save),
    path('studentadd', studentrender),
    path('add_student', add_student),
    path('view_student', view_student),
    path('removedata1',removedata1),
    path('updatedata1',updatedata1),
    path('save1',save1),

]
